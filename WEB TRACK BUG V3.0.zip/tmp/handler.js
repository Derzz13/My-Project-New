{
	"name": "Tracking By Xemzz",
	"starthandler": "startTracking",
	"stophandler": "stopTracking",
	"start": "xemzzMulaiPelacakan",
	"stop": "xemzzHentikanPelacakan"
}